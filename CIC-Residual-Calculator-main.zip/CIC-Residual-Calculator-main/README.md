# CIC-Residual-Calculator
CIC Residual Calculator

<h1 style="width:100px;text-align:left; padding: 10px 0px 0px 90px;"><strong><span style="font-family:Arial,Helvetica,sans-serif">Call It Closed Residual Calculator</span></strong></h1>

    overflow: hidden;
        text-overflow: clip;
        white-space: nowrap;